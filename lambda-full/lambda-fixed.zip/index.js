module.exports = require(\"./lambda-handler\");
